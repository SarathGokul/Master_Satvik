

context('Dummy test',() =>{
it('satwik 1st testcase',()=>{
    cy.visit('https://www.cypress.io/');
})

it('satwik 2nd testcase',()=>{
    cy.visit('https://www.phptravels.net');
})
})